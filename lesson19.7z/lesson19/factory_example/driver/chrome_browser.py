from .browser import Browser

class ChromeBrowser(Browser):
    _name = 'chrome'
