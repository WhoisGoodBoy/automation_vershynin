from .browser import Browser

class FirefoxBrowser(Browser):
    _name = 'firefox'